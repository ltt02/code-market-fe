<template>
    <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" :ellipsis="false"
        @select="handleSelect">
        <el-menu-item index="0">
            <img style="width: 100px" src="@\assets\images\code-market-high-resolution-logo-transparent.svg" alt="Element logo" />
        </el-menu-item>
        <el-menu-item index="1">Trang chủ</el-menu-item>
        <el-menu-item index="2">Phần mềm</el-menu-item>
        <el-menu-item index="3">Đăng nhập</el-menu-item>
    </el-menu>
</template>

<script lang="ts" setup>
import { ref } from 'vue'

const activeIndex = ref('1')
const handleSelect = (key: string, keyPath: string[]) => {
    console.log(key, keyPath)
}
</script>

<style>
.el-menu--horizontal>.el-menu-item:nth-child(3) {
    margin-right: auto;
}

.el-menu--horizontal>.el-menu-item {
    color: #fff;
}


.el-menu {
    background-color: #121216;
}

.el-menu--horizontal .el-menu-item:not(.is-disabled):focus, .el-menu--horizontal .el-menu-item:not(.is-disabled):hover {
    color: rgba(255, 255, 255, .65);
    background-color: #121216;
    outline: none;
}

/* .el-menu--horizontal>.el-menu-item.is-active {
    border-bottom: 2px solid #fff;
    color: #fff !important;
} */
</style>