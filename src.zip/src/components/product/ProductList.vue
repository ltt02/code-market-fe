<template>
    <div class="product-list-container">
        <div class="product-list-title">
            <a href="#">
                <h5 class="">
                    Phần mềm mới
                </h5>
            </a>
        </div>
        <Carousel class="product-list-slide" :items-to-show="5" :autoplay="0" :wrap-around="true">
            <Slide v-for="application in applicationList" :key="application">
                <ProductCard :application="application"/>
            </Slide>
        </Carousel>
    </div>
</template>

<script setup>
import { ref } from 'vue'
import ProductCard from '@/components/product/ProductCard.vue'
import 'vue3-carousel/dist/carousel.css'
import { Carousel, Slide, Pagination, Navigation } from 'vue3-carousel'
import ApplicationService from "@/services/application.service.js"

const applicationList = ref([]);

const retrieveApplicationList = async () => {
    try {
        applicationList.value = await ApplicationService.getAll();
    } catch (error) {
        console.log(error);
    }
}

const init = () => {
    retrieveApplicationList();
}

init();
</script>

<style>
.product-list-container {
    margin-bottom: 64px;
    position: relative;
}

.product-list-title {
    margin: 0 0 18px;
    display: flex;
    -webkit-box-pack: justify;
    justify-content: space-between;
}

.product-list-title a {
    text-decoration: none;
}

.product-list-title a h5 {
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    font-size: 1.25rem;
    margin: 0;
    padding: 0;
}

.product-list-slide {
    display: flex;
}
</style>